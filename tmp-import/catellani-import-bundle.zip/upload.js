// Drives the Simetria admin import wizard for each Excel file given on the command line.
const { chromium } = require("playwright");
const fs = require("fs");
const BASE = "https://simetrialt.vercel.app";
const log = (...a) => { const s = `[${new Date().toISOString()}] ${a.join(" ")}`; console.log(s); fs.appendFileSync("upload.log", s + "\n"); };

(async () => {
  const files = process.argv.slice(2);
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1400, height: 1000 } });
  const page = await ctx.newPage();
  page.setDefaultTimeout(120000);
  await page.goto(`${BASE}/admin/login`, { waitUntil: "networkidle", timeout: 90000 });
  await page.fill('input[name="email"]', process.env.ADMIN_EMAIL);
  await page.fill('input[name="password"]', process.env.ADMIN_PASSWORD);
  await page.click('button:has-text("Prisijungti")');
  await page.waitForURL((u) => !u.pathname.includes("login"), { timeout: 90000 });
  log("logged in", page.url());

  for (const file of files) {
    log("=== file", file);
    await page.goto(`${BASE}/admin/products/import`, { waitUntil: "networkidle", timeout: 90000 });
    await page.setInputFiles('input[type="file"]', file);
    const cb = page.locator('label:has-text("automatiškai ieškoti") input[type="checkbox"]');
    if (await cb.isChecked()) await cb.uncheck();
    await page.click('button:has-text("Analizuoti dokumentus")');
    const t0 = Date.now();
    const publishBtn = page.locator('button:has-text("Patvirtinti ir įrašyti")');
    const err = page.locator('text=/Nepavyko|klaida|Error/i');
    while (!(await publishBtn.count())) {
      if (Date.now() - t0 > 15 * 60000) throw new Error("analysis timeout");
      if ((await err.count()) && !(await page.locator('button:has-text("Skaitoma")').count())) {
        log("ANALYSIS ERROR:", (await err.first().textContent()).slice(0, 300));
        await page.screenshot({ path: `err-analyze-${Date.now()}.png` });
        break;
      }
      await page.waitForTimeout(5000);
    }
    if (!(await publishBtn.count())) continue;
    const label = await publishBtn.textContent();
    log("analysed in", Math.round((Date.now() - t0) / 1000), "s ->", label);
    await page.screenshot({ path: `preview-${files.indexOf(file) + 1}.png` });
    await publishBtn.click();
    const t1 = Date.now();
    let resumes = 0;
    let lastProgress = "";
    while (true) {
      if (await page.locator("text=Nauji produktai:").count()) break;
      const resume = page.locator('button:has-text("Tęsti nuo")');
      if ((await resume.count()) && (await resume.isEnabled())) {
        const notice = await page.locator('text=/Įrašyta iki šiol/').first().textContent().catch(() => "");
        log("save error, resuming:", (notice || "").slice(0, 300));
        if (++resumes > 40) throw new Error("too many resumes");
        await page.waitForTimeout(5000);
        await resume.click();
      }
      const prog = await page.locator('button:has-text("Įrašoma")').textContent().catch(() => "");
      if (prog && prog !== lastProgress) { lastProgress = prog; log(prog); }
      if (Date.now() - t1 > 60 * 60000) throw new Error("publish timeout");
      await page.waitForTimeout(5000);
    }
    const summary = await page.locator("text=Nauji produktai:").first().textContent();
    const errors = await page.locator("text=/Nauji produktai/").locator("xpath=following::*[contains(@class,'red') or contains(text(),'klaida')]").allTextContents().catch(() => []);
    log("DONE", file, "in", Math.round((Date.now() - t1) / 1000), "s:", summary, errors.join(" | ").slice(0, 500));
    await page.screenshot({ path: `done-${files.indexOf(file) + 1}.png` });
  }
  await browser.close();
  log("ALL DONE");
})().catch(async (e) => { log("FATAL", e.message); process.exit(1); });
