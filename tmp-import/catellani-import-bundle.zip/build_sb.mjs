// Builds the import Excel for the remaining Catellani & Smith products.
import { createRequire } from "node:module";
import fs from "node:fs";
const req = createRequire(process.cwd() + "/package.json");
const XLSX = req("xlsx");
const S = process.argv[2]; // scratchpad dir
const OUT = process.argv[3];

const payload = JSON.parse(fs.readFileSync(`${S}/payload.json`, "utf8"));
const rows = payload.rows;
const raw = JSON.parse(fs.readFileSync(`${S}/allphotos.json`, "utf8"));
const photos = Object.fromEntries(Object.entries(raw).map(([k, v]) => [k, (v || []).slice(0, 3)]));
const done = new Set(payload.done);
const ACCESSORY = /^(Drivers|Power Supply Kits|Gel Box System|Quick Connectors System|Accessories)/i;

const SLUGS = {
  "Pòta!": (t) => (/wall/.test(t) ? "pota-w" : /plug/.test(t) ? "pota-plug-diver" : "pota"),
  "Par 18 Chandelier": "par-18-chandelier", "Par 18": (t) => (/mod\./.test(t) ? "par-18-jc-ic" : "par-18"),
  "Ensō": (t) => (/wall/.test(t) ? "enso-w" : "enso"), "Sfera": "sfera-w", "Cono": "cono-w", "Atman": "atman",
  "Ettorino": "ettorino-t", "Ettorino BIG": "ettorino-big", "Ale BIG": "ale-big",
  "Ale": (t) => (/ceiling/.test(t) ? "ale-c" : "ale-be-t"),
  "Petits Bijoux": (t, d) => (/56/.test(d) ? "56-petits-bijoux" : "28-petits-bijoux"), "Petites Lentilles": "22-petites-lentilles",
  "Lederam Manta S2": "lederam-manta-s2", "Lederam Manta S1": "lederam-manta-s1", "Lederam Manta CWS1": "lederam-manta-cws1",
  "Lederam C180": "lederam-c180", "Lederam C150": "lederam-c150", "Lederam C2": "lederam-c2", "Lederam WF": "lederam-wf",
  "Lederam W": "lederam-w", "Lederam W1": "lederam-w1", "Lederam T1": "lederam-t1", "Lederam F0": "lederam-f0",
  "Lederam F1": "lederam-f1", "Lederam F2": "lederam-f2", "Lederam F3": "lederam-f3",
  "Sorry Giotto": (t, d, sku) => (/^SG1$/.test(sku) ? "sorry-giotto-1" : /^SG3/.test(sku) ? "sorry-giotto-3" : "sorry-giotto-9-12"),
  "Light Stick": (t) => (/standing/.test(t) ? "light-stick-f" : /ceiling/.test(t) ? "light-stick-cw" : "light-stick-v"),
  "Wa Wa": "wa-wa-f", "Uau": "uau-f", "Giulietta BE": (t) => (/standing/.test(t) ? "giulietta-be-f" : "giulietta-be-t"),
  "Jackie O": "jackie-o", "Jackie O Chandelier": (t, d) => (/\b(15|20|24)x/.test(d) ? "jackie-o-chandelier-15-20-24" : "jackie-o-chandelier-6-9-12"),
  "Malagolina": "postkrisi-10-malagolina", "PostKrisi 50": "postkrisi-50-51-52", "PostKrisi 51": "postkrisi-50-51-52", "PostKrisi 52": "postkrisi-50-51-52",
  "PostKrisi 100": "postkrisi-f-100", "PostKrisi 21": "postkrisi-w-21-40", "PostKrisi 40": "postkrisi-w-21-40", "PostKrisi 70": "postkrisi-cw-70",
  "PostKrisi 49": "postkrisi-49", "PostKrisi 61": "postkrisi-t-61", "PostKrisi 64": "postkrisi-f-64",
  "PostKrisi 65": "postkrisi-65-66-67", "PostKrisi 66": "postkrisi-65-66-67", "PostKrisi 67": "postkrisi-65-66-67", "PostKrisi Chandelier": "pk-chandelier",
  "Nuvola": "fil-de-fer-nuvola",
  "Fil de Fer": (t) => (/floor|standing/.test(t) ? (/230V \(110V/.test(t) ? "fil-de-fer-f-outdoor" : "fil-de-fer-f") : /not dimmable/.test(t) ? "fil-de-fer-outdoor" : "fil-de-fer"),
  "Sweet Light Chandelier": "sweet-light-chandelier", "Sweet Light": "sweet-light-t", "Uomo della Luce S": "uomo-della-luce-s", "Uomo della Luce XXL": "uomo-della-luce-xxl-outdoor",
  "Lucenera 504": "lucenera-504", "Lucenera 206": "lucenera-206", "Lucenera 502": "lucenera-502-503", "Lucenera 503": "lucenera-502-503", "Lucenera 506": "lucenera-506", "Lucenera 500": "lucenera-500",
  "Bellatrix": "bellatrix", "Pepita 102": "pepita-102", "Pepita 65": "pepita-65", "EC 301": "ec-301",
  "Stchu-Moon 02": (t) => (/bulbs not supplied/.test(t) ? "stchu-moon-02" : "stchu-moon-02-230v"), "Stchu-Moon Chandelier": "stchu-moon-02-chandelier",
  "Stchu-Moon 05": "stchu-moon-05", "Stchu-Moon 01": "stchu-moon-01", "Stchu-Moon 09": "stchu-moon-09", "Stchu-Moon 08": "stchu-moon-08", "Stchu-Moon R": "stchu-moon-r", "Stchu-Moon SR": "stchu-moon-sr",
  "Gold Moon Chandelier": "gold-moon-chandelier", "Gold Moon": (t) => (/wall/.test(t) ? "gold-moon-w" : "gold-moon-jc-ic"),
  "Malagola": "malagola", "Disco": "disco", "Luna": "luna-w", "Luna Piena": "luna-piena", "Francesca": "francesca",
  "Luce d’Oro": (t) => (/standing/.test(t) ? "luce-doro-f" : "luce-doro-t"), "Colonna": "colonna",
  "Turciù": (t) => (/36 flex|21 flex|16 flex/.test(t) ? "turciu-16-21-36" : /9 flex/.test(t) ? "turciu-9" : /5 flex/.test(t) ? "turciu-5" : "turciu-2-3"),
  "Bonsai": "bonsai", "Albero della Luce": "albero-della-luce", "Sottovento": "sottovento", "For You": "for-you",
  "Lola": (t) => (/standing/.test(t) ? "lola-f" : "lola-t"), "Luce che dipinge": "luce-che-dipinge", "Herem": "herem-t", "Nike": "nike",
  "Shadow": "shadow", "U.": "u-w", "CicloItalia": (t) => (/with flex/.test(t) ? (/wall/.test(t) ? "cicloitalia-flex-w1" : "cicloitalia-flex-f3") : /standing/.test(t) ? "cicloitalia-f" : "cicloitalia-t"),
  "Talismano": "talismano-other-smiths", "Alchemie": (t) => (/standing|floor/.test(t) ? "alchemie-f" : "alchemie-t"),
  "Medousê": (t) => (/wall/.test(t) ? "medouse-w" : "medouse-f"), "More": (t) => (/floor/.test(t) ? "more-0" : /pendant/.test(t) ? "more" : "more-f"),
  "Syphasera": "syphasera", "Syphasfera": "syphasfera", "Syphaduepassi": "syphaduepassi", "Trenta": "trenta",
  "Gemma": "gemma", "Miracolo": "miracolo", "Occhibelli": "occhibelli",
};
const MDL = /^Macchina della Luce/;

const typologyOf = (type, name) => {
  const t = `${type} ${name}`.toLowerCase();
  if (/pendant|chandelier|suspension/.test(t)) return "Pendant Lights";
  if (/recessed/.test(t)) return "Recessed Lights";
  if (/ceiling/.test(t)) return "Ceiling Lights";
  if (/standing|floor/.test(t)) return "Floor Lamps";
  if (/wall/.test(t)) return "Wall Lights";
  if (/table|usb/.test(t)) return "Table Lights";
  return "Pendant Lights";
};
const TECH = /\bLED\b|\bW\b|\d+x[\d,]+W|bulb|dimm|driver|board|push|triac|dali|on request|see page|not supplied|E27|G4|G9|\bIP\d|max |connect|strip|wireless|on\/off|version|available|touch|not incl|\*|cable|jack|tensioner|plug|rechargeable|battery/i;
const COLOUR = /\b(black|white|gold|golden|copper|brass|bronze|silver|nickel|chrome|satin|matt|grey|gray|anthracite|blue|red|green|yellow|orange|pink|beige|ivory|cream|brown|natural|transparent|transp\.|smoke|amber|colourful|fluo|rust|iron|steel|aluminium|wood|glass|crystal|rough|waxed|vintage|untreated|burnished)\b/i;
const SIZE = /\d+(?:[.,]\d+)?\s*(cm|mm|m)\b|Ø\s*\d|\b\d{2,4}\s*x\s*\d{2,4}\b/i;
const KELVIN = /\b(\d{4})\s*K\b/;

const GM_MODEL = (sku) => (/G$/.test(sku) ? "Grappolo" : "Cascata");
function build(r) {
  const fam = r.family.trim();
  let forcedName = "";
  if (fam === "Gold Moon Chandelier") {
    const model = GM_MODEL(r.sku);
    const spl = r.desc.match(/(\d+)x GM.*?(\d+)x SPL/);
    const n = spl ? Number(spl[1]) + Number(spl[2]) : Number(r.desc.match(/(\d+)x1,1W/)[1]);
    forcedName = `Gold Moon Chandelier pendant lamp – ${model}, ${n} lights${spl ? ` incl. ${spl[2]} Spot Light` : ""}`;
    r = { ...r, desc: `${model} / satin steel base Ø 78 cm / H 300 cm not adjustable / ${spl ? `${spl[1]}x black/gold shades Ø 20 cm + ${spl[2]}x black/brass Spot Light pendants / ${spl[1]}x1,1W + ${spl[2]}x1,7W 24Vdc LED board` : r.desc} / with jack / Triac dimmable` };
  }
  r = { ...r, type: r.type.replace(/celing/g, "ceiling").replace(/\s+110V.*$/, "").replace(/\s*\/\s*$/, "").trim() || r.type };
  const typeSegs = r.type.split(/\s+\/\s+/);
  const typeMain = typeSegs.filter((s) => /lamp|light|chandelier|flex/i.test(s) && !/V\b|dimm|bulb|driver|board|plug|version|not incl/i.test(s));
  const shortType = typeMain.join(" ").replace(/\s+/g, " ").trim() || typeSegs[0];
  const typeSize = typeSegs.filter((s) => SIZE.test(s) && !/flex/i.test(s));
  const descSegs = r.desc.split(/\s+\/\s+/).map((s) => s.trim()).filter(Boolean);
  let kelvin = "";
  const led = r.desc.match(/(\d+)x[\d,]+W/);
  const tokens = [];
  for (const s of descSegs) {
    const k = s.match(KELVIN);
    if (k) kelvin = `${k[1]}K`;
    if (TECH.test(s) && !/^(shade|disc|discs|base|rod|rods)\b/i.test(s)) continue;
    if (/^\d+x[\d,]+W/i.test(s)) continue;
    tokens.push(s.replace(/\s+\d+x[\d,]+W.*$/i, "").trim());
  }
  const all = [...typeSize.filter((ts) => !tokens.some((t) => t.includes(ts.trim()))), ...tokens].filter(Boolean);
  let name = `${fam} ${shortType}`.trim();
  if (all.length) name += ` – ${all.join(", ")}`;
  if (kelvin) name += `, ${kelvin}`;
  if (forcedName) name = forcedName;
  const colour = tokens.filter((t) => COLOUR.test(t)).join(", ");
  const dims = all.filter((t) => SIZE.test(t)).join(", ");
  const slugFn = MDL.test(fam) ? "macchina-della-luce" : SLUGS[fam];
  const slug = typeof slugFn === "function" ? slugFn(r.type, r.desc, r.sku) : slugFn;
  const imgs = slug ? photos[slug] ?? [] : [];
  const net = r.price;
  const price = Math.round(net * 1.21 * 100) / 100;
  const typology = typologyOf(r.type, name);
  const description = `${fam} by Catellani & Smith – ${r.type}.\n\nSpecification: ${r.desc}` + (kelvin ? `\nColour temperature: ${kelvin}` : "");
  return { sku: r.sku, name, ledTok: led ? `${led[1]} LED` : "", description, typology, colour, dims, price, net, imgs, slug, fam, page: r.page };
}

const todo = rows.filter((r) => !done.has(r.sku) && !ACCESSORY.test(r.family) && !/net price to be added/i.test(r.desc));
const items = todo.map(build);
for (const i of items) { const same = items.filter((j) => j.name === i.name); if (same.length > 1 && i.ledTok && new Set(same.map((j) => j.ledTok)).size > 1) i.name += `, ${i.ledTok}`; }
const noSlug = items.filter((i) => !i.slug);
const noImg = items.filter((i) => i.slug && !i.imgs.length);
console.log("items", items.length, "no slug:", [...new Set(noSlug.map((i) => i.fam))], "no photos:", [...new Set(noImg.map((i) => i.slug))]);
const dupNames = items.map((i) => i.name).filter((n, i, a) => a.indexOf(n) !== i);
console.log("duplicate names:", dupNames.length, dupNames.slice(0, 8));

const header = ["Article no.", "Product name", "Description", "Brand", "Category", "Type", "Material", "Colour", "Dimensions", "Price EUR", "Catalogue net", "Currency", "Image URL", "Product page"];
const toRow = (i) => [i.sku, i.name, i.description, "Catellani & Smith", "Lighting", i.typology, "", i.colour, i.dims, i.price, i.net, "EUR", i.imgs.join("\n"), i.slug ? `https://www.catellanismith.com/en/${i.slug}/` : ""];
function write(file, title, list) {
  const aoa = [[title], ["Website price = catalogue RRP (VAT excl.) + 0% transport (List.xlsx) + 21% VAT. Photos: catellanismith.com product pages"], header, ...list.map(toRow)];
  const ws = XLSX.utils.aoa_to_sheet(aoa);
  ws["!cols"] = [{ wch: 12 }, { wch: 60 }, { wch: 80 }, { wch: 18 }, { wch: 10 }, { wch: 16 }, { wch: 10 }, { wch: 24 }, { wch: 22 }, { wch: 10 }, { wch: 12 }, { wch: 8 }, { wch: 90 }, { wch: 50 }];
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Products");
  XLSX.writeFile(wb, file);
}
fs.mkdirSync(OUT, { recursive: true });
write(`${OUT}/Catellani-Smith-all-remaining-${items.length}.xlsx`, `Catellani & Smith – remaining products (price list 2026-2027, Simetria kainynas nuo 2026-05)`, items);
const CH = 60;
for (let i = 0; i < items.length; i += CH) {
  const part = items.slice(i, i + CH);
  const n = i / CH + 1;
  write(`${OUT}/Catellani-Smith-part-${String(n).padStart(2, "0")}-of-${Math.ceil(items.length / CH)}.xlsx`, `Catellani & Smith – part ${n} (price list 2026-2027, Simetria kainynas nuo 2026-05)`, part);
}
fs.writeFileSync(`${OUT}/items.json`, JSON.stringify(items, null, 1));
for (const i of items.filter((_, k) => k % 23 === 0)) console.log(i.sku, "|", i.name, "|", i.typology, "|", i.price, "|", i.slug);
